# Feature Flags для новой системы параметров

# Установите в true для включения функций, false для отключения

# Новая система параметров (шаблоны, переопределения)

NEXT_PUBLIC_ADVANCED_PARAMETERS=false

# Система предложений пользователей

NEXT_PUBLIC_USER_SUGGESTIONS=false

# Инфографическая визуализация продуктов

NEXT_PUBLIC_PRODUCT_VISUALIZATION=false

# Цветовые квадратики вместо текста

NEXT_PUBLIC_COLOR_SQUARES=false

# Дополнительные заметки в конфигураторе

NEXT_PUBLIC_CUSTOM_NOTES=false

# Включить все функции сразу (для тестирования)

# NEXT_PUBLIC_ADVANCED_PARAMETERS=true

# NEXT_PUBLIC_USER_SUGGESTIONS=true

# NEXT_PUBLIC_PRODUCT_VISUALIZATION=true

# NEXT_PUBLIC_COLOR_SQUARES=true

# NEXT_PUBLIC_CUSTOM_NOTES=true
